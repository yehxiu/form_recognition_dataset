# table > 2023-11-06 8:46pm
https://universe.roboflow.com/yehxiu/table-81ukl

Provided by a Roboflow user
License: Public Domain

